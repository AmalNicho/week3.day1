package week3.day1.Assignment2.org.student;

import week3.day1.Assignment2.org.department.Department;

public class Student extends Department{
	public void studentName() {
		System.out.println("Student Name is Amal anto Nicho");
	}
	
	public void studentDept() {
		System.out.println("Student Department is ECE");
	}
	
	public void studentID() {
		
		System.out.println("ID is 100000");
	}

}
