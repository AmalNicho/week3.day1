package week3.day1.Assignment2.org.department;

import week3.day1.Assignment2.org.college.College;

public class Department extends College {

	public void Deptname() {
		
		System.out.println("Department is ECE");
	}
}
