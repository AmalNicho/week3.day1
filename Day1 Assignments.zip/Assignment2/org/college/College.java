package week3.day1.Assignment2.org.college;

public class College {

	public void collegename() {
		System.out.println("College Name is St.Joseph Engg College");
		}
	
	public void collegecode() {
		System.out.println("College Code is A001");
	}
	
	public void collegerank() {
		System.out.println("College Rank is 20");
	}
	
}
