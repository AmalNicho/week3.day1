package week3.day1.Assignment2.org.StudentFullDetails;

import week3.day1.Assignment2.org.student.Student;

public class StudentFullDetails {
	public static void main(String[] args) {
		
		Student student = new Student();
		
		student.collegename();
		student.collegecode();
		student.collegerank();
		student.Deptname();
		student.studentName();
		student.studentDept();
		student.studentID();
	}

}
