package week3.day1.Assignment3.Banks;

public class MyBank {
	

	void banklocation() {
		System.out.println("Chennai");
	}
	
	
		
	public static void main(String[] args) {
		
		AxisBanks axisBanks = new AxisBanks();
		
		axisBanks.deposit();
		
		axisBanks.Fixed();
		
		axisBanks.Saving();
		
		
		
	}

}
