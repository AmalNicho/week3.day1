package week3.day1.Assignment3.Banks;

public class BankInfo {
	
	 final void Saving() {
		 System.out.println("Anyone can open Saving Account");
	 }
	 
	 void Fixed() {
		 System.out.println("Minimum 5 year debosit needs to be done");
	 }
	 
	 void deposit() {
		 System.out.println("Minimum balance should be 500 Rs");
	 }

}
