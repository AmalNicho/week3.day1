package week3.day1.Assignment3.Banks;

public class AxisBanks extends BankInfo {
	
	 void deposit() {
		 System.out.println("Minimum balance should be 10000 Rs");
	 }

	 
	 

}
