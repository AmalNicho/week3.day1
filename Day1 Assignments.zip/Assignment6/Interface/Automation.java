package week3.day1.Assignment6.Interface;

public class Automation implements Language, TestTool {

	void automation() {

		System.out.println("Necessary tool for Selenium Automation");
		this.Selenium(); //Used this Keyword is here
	
		this.Java();
	}

	public void Selenium() {

		System.out.println("Eclipse Software is required");

	}

	public void Java() {
		System.out.println("Java 8 version is required");

	}

	public static void main(String[] args) {

		Automation automation = new Automation();

		automation.automation();
		}

}
