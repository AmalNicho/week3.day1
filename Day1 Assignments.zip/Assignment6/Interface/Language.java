package week3.day1.Assignment6.Interface;

public interface Language {

	void Java();
	
	
	
	
}
