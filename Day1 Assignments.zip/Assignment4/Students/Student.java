package week3.day1.Assignment4.Students;

public class Student {
	
	void getStudentInfo(int id) {
	System.out.println("Student ID is "+ id);	
	}

	void getStudentInfo(int id,String Name) {
	System.out.println("Student ID is "+ id+". and Student Name is "+Name);	
	}

	void getStudentInfo(int id,String Name,long phonenumber) {
	System.out.println("Student ID is "+ id+".  Student Name is "+Name+". Phone number is "+phonenumber);	
	}

	void getStudentInfo(int id,String Name,long phonenumber,String email ) {
	System.out.println("Student ID is "+ id+".  Student Name is "+Name+". Phone number is "+phonenumber+" Mail Address is "+email);	
	}
	
	public static void main(String[] args) {
		
		Student student = new Student();
		student.getStudentInfo(200);
		student.getStudentInfo(200, "Amalanto Nicho");
		student.getStudentInfo(200, "Amalanto Nicho",989899777777L);
		student.getStudentInfo(200, "Amalanto Nicho",989899777777L,"amalnicho@gmail.com");
		
		
		
	}
	
}
