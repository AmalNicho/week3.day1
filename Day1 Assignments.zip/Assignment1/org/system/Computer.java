package week3.day1.Assignment1.org.system;

public class Computer {
	
	final void Companyname() {
		System.out.println("Dell");
	}
	
	void computerModel() {
		System.out.println("dell inspiron");
	}

}
