package week3.day1.Assignment1.org.system;

public class Desktop extends Computer{

	void desktopsize() {
		System.out.println("Dell 10.5");
		
	}
	
	void computerModel () {
		
		System.out.println("Dell Vostro");
	}
	
	void ParentComputerModel () {
		super.computerModel(); //Used Super Key word
	}

	// Checking whether final method can override. It cant be overriden
//	void Companyname() {
//		System.out.println("Lenova");
//	}
	
}
