package week3.day1.Assignment1.org.system;

public class MySystem {
	
	
	public static void main(String[] args) {
		
		Desktop desktop = new Desktop();
		desktop.Companyname();
		desktop.computerModel();
		desktop.desktopsize();
		desktop.ParentComputerModel();
		
		
	}

}
